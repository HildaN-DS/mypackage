# mypackage
This library was created as an example on how to publish a package

## building it locally
`python setup.py sdist`

## installing the package from github
`pip install git+https://github.com/HildaN-DS/mypackage.git`

## updating the package from github
`pip install --upgrade git+https://github.com/HildaN-DS/mypackage.git`
