# mypackage
This library was created as an example on how to publish a package

# How to install
....